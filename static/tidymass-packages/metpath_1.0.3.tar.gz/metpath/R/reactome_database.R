# library(rWikiPathways)
# wp.hs.gmt <- rWikiPathways::downloadPathwayArchive(organism="Homo sapiens", format = "gmt")
# wp2gene <- readPathwayGMT(wp.hs.gmt)
